const translations = {
    en: {
        sidebar_tagline: "Business transformation, not tech theatre",
        philosophy_title: "Technology is the enabler. Business improvement is the outcome.",
        philosophy_text: "Every workflow, dashboard, automation, and digital solution should remove friction and create measurable business value.",
        nav_home: "Home",
        nav_about: "Profile",
        nav_education: "Education",
        nav_experience: "Experience",
        nav_skills: "Capabilities",
        nav_contact: "Contact",
        signal_1_label: "Focus",
        signal_1_text: "Operational excellence",
        signal_2_label: "Approach",
        signal_2_text: "Business-led automation",
        signal_3_label: "Outcome",
        signal_3_text: "Clearer, faster, smarter execution",
        hero_kicker: "Operations improvement, automation, analytics",
        hero_title: "LINZHI helps organisations work smarter by combining operational judgement with technology-enabled execution.",
        hero_subtitle: "A portfolio built around business outcomes, not technology for its own sake.",
        hero_desc: "The work here focuses on reducing inefficiency, improving visibility, strengthening decision-making, and building digital solutions that people can actually use in real operating environments.",
        hero_btn_1: "See impact",
        hero_btn_2: "View profile",
        metric_1: "Business problems framed in operational terms before any solution design starts.",
        metric_2: "Data and automation used to improve execution, not to add unnecessary complexity.",
        metric_3: "Transformation work grounded in governance, adoption, and measurable value.",
        portrait_role: "Business automation specialist with an operational mindset",
        float_1_label: "Business lens",
        float_1_title: "Improve process performance before increasing tool complexity.",
        float_2_label: "Execution lens",
        float_2_title: "Build systems people can adopt, govern, and sustain.",
        about_tag: "Profile",
        about_title: "Closer to a digital transformation consultant than a traditional developer portfolio.",
        about_p1: "The emphasis is not on programming languages or frameworks. The emphasis is on understanding operations, identifying inefficiencies, improving workflows, and using technology where it creates practical business value.",
        about_p2: "This profile is built around business understanding, process thinking, analytics, and disciplined use of automation to make organisations more productive and more manageable.",
        about_p3: "The goal is simple: help teams work with more clarity, stronger control, better visibility, and less wasted effort.",
        stat_1_number: "People",
        stat_1_label: "Solutions designed around real team behaviour and adoption.",
        stat_2_number: "Process",
        stat_2_label: "Workflow redesign aimed at clarity, speed, and accountability.",
        stat_3_number: "Data",
        stat_3_label: "Decision support shaped for action, not reporting theatre.",
        edu_title: "Education",
        edu_degree_1: "Bachelor of Information Technology, National University of Singapore",
        edu_desc_1: "Focused on business analytics, digital systems, data thinking, and technology-enabled problem solving.",
        edu_degree_2: "Human capital and business operations background",
        edu_desc_2: "Developed practical understanding of workforce coordination, organisational realities, and business support functions.",
        exp_title: "Experience",
        exp_label_1: "Operational visibility",
        exp_title_1: "Analytics and reporting improvement",
        exp_duration_1: "Business problem to decision support",
        exp_item_1_1: "Reduced fragmented reporting by designing cleaner KPI and dashboard structures.",
        exp_item_1_2: "Improved management visibility into workforce, process, and operational signals.",
        exp_item_1_3: "Helped convert raw data into more timely and confident decisions.",
        exp_label_2: "Workflow redesign",
        exp_title_2: "Automation and digital process improvement",
        exp_duration_2: "Operational friction to cleaner execution",
        exp_item_2_1: "Applied automation to repetitive work where it could remove manual waste and inconsistency.",
        exp_item_2_2: "Structured digital workflows around usability, adoption, and governance needs.",
        exp_item_2_3: "Focused on practical systems that improve handoffs, accountability, and team productivity.",
        exp_label_3: "Transformation framing",
        exp_title_3: "Business-led solution design",
        exp_duration_3: "Technology as a supporting tool",
        exp_item_3_1: "Defined problems in business terms before proposing technical responses.",
        exp_item_3_2: "Balanced efficiency improvement with resilience, governance, and operational reality.",
        exp_item_3_3: "Positioned digital solutions around value creation rather than feature showcase.",
        skills_title: "Capabilities",
        skill_title_1: "Operational excellence",
        skill_text_1: "Process mapping, friction identification, workflow redesign, and service visibility improvement.",
        skill_title_2: "Automation and productivity",
        skill_text_2: "Selective automation and AI support to reduce repetitive work and improve consistency.",
        skill_title_3: "Analytics and decision support",
        skill_text_3: "KPI design, dashboard logic, reporting structure, and business-facing data storytelling.",
        skill_title_4: "Governance-aware transformation",
        skill_text_4: "Control thinking, adoption planning, accountability structure, and practical digital implementation.",
        contact_title: "Contact",
        contact_subtitle: "Open to conversations about transformation, analytics, automation, and operational improvement.",
        contact_text: "If you are looking for someone who understands business operations and uses technology as a practical lever for improvement, this is the right conversation to start.",
        contact_email_label: "Email",
        contact_location_label: "Location",
        contact_location_value: "China and Singapore",
        label_name: "Your Name",
        label_email: "Your Email",
        label_message: "Your Message",
        send_btn: "Send Message",
        success_text: "Message submitted. Thank you.",
        footer_1: "© 2026 LINZHI. All rights reserved.",
        footer_2: "Business understanding, systems thinking, and technology-enabled execution."
    },
    zh: {
        sidebar_tagline: "不是技术炫技，而是业务改善",
        philosophy_title: "技术只是手段。业务改善才是结果。",
        philosophy_text: "每一个工作流、看板、自动化动作和数字化方案，都应该减少摩擦并创造可衡量的业务价值。",
        nav_home: "首页",
        nav_about: "Profile",
        nav_education: "教育",
        nav_experience: "经验",
        nav_skills: "能力",
        nav_contact: "联系",
        signal_1_label: "重点",
        signal_1_text: "运营卓越",
        signal_2_label: "方法",
        signal_2_text: "业务导向自动化",
        signal_3_label: "结果",
        signal_3_text: "更清晰、更快速、更聪明的执行",
        hero_kicker: "运营优化、自动化、数据分析",
        hero_title: "LINZHI 通过把运营判断力与技术化执行结合起来，帮助组织更聪明地运作。",
        hero_subtitle: "这不是一个为了展示技术而存在的作品集，而是一个围绕业务结果展开的作品集。",
        hero_desc: "这里的工作重点，是减少低效、提升可视化、强化决策质量，并构建能在真实业务环境中被团队采用的数字化方案。",
        hero_btn_1: "查看成果",
        hero_btn_2: "查看定位",
        metric_1: "所有方案设计都先从业务问题和运营现实出发。",
        metric_2: "数据和自动化被用来提升执行效率，而不是增加不必要的复杂度。",
        metric_3: "转型工作同时关注治理、采纳与可衡量价值。",
        portrait_role: "具备运营思维的业务自动化实践者",
        float_1_label: "业务视角",
        float_1_title: "先提升流程表现，再增加工具复杂度。",
        float_2_label: "落地视角",
        float_2_title: "构建团队能采纳、能治理、能持续使用的系统。",
        about_tag: "Profile",
        about_title: "这更像一个数字化转型顾问的作品集，而不是传统开发者作品集。",
        about_p1: "重点不是编程语言和框架，重点是理解运营、识别低效、优化流程，并在真正能创造价值的地方使用技术。",
        about_p2: "这个定位建立在业务理解、流程思维、分析能力，以及对自动化的克制使用之上，目标是让组织更高效、更可管理。",
        about_p3: "核心目标很简单：帮助团队拥有更高的清晰度、更强的控制力、更好的可视化，以及更少的浪费。",
        stat_1_number: "People",
        stat_1_label: "围绕真实团队行为与采纳难度来设计方案。",
        stat_2_number: "Process",
        stat_2_label: "工作流重构聚焦清晰度、速度与责任边界。",
        stat_3_number: "Data",
        stat_3_label: "决策支持服务于行动，而不是汇报表演。",
        edu_title: "教育",
        edu_degree_1: "新加坡国立大学 信息技术学士",
        edu_desc_1: "聚焦商业分析、数字系统、数据思维与技术驱动的问题解决。",
        edu_degree_2: "人力资本与业务运营背景",
        edu_desc_2: "建立了对劳动力协同、组织现实与业务支持职能的实践理解。",
        exp_title: "经验",
        exp_label_1: "运营可视化",
        exp_title_1: "分析与汇报优化",
        exp_duration_1: "从业务问题到决策支持",
        exp_item_1_1: "通过更清晰的 KPI 与看板结构，减少碎片化汇报。",
        exp_item_1_2: "提升管理层对用工、流程与运营信号的可视化能力。",
        exp_item_1_3: "帮助把原始数据转化为更及时、更有把握的决策支持。",
        exp_label_2: "流程重构",
        exp_title_2: "自动化与数字流程改善",
        exp_duration_2: "从运营摩擦到更干净的执行",
        exp_item_2_1: "在合适场景下应用自动化，减少重复劳动与不一致。",
        exp_item_2_2: "围绕可用性、采纳和治理要求来设计数字工作流。",
        exp_item_2_3: "聚焦真正能改善交接、责任边界和团队产能的实用系统。",
        exp_label_3: "转型 framing",
        exp_title_3: "业务导向方案设计",
        exp_duration_3: "把技术放在支持位置",
        exp_item_3_1: "先用业务语言定义问题，再提出技术响应方案。",
        exp_item_3_2: "在效率提升、韧性、治理和运营现实之间做平衡。",
        exp_item_3_3: "让数字化方案围绕价值创造，而不是功能展示。",
        skills_title: "能力",
        skill_title_1: "运营卓越",
        skill_text_1: "流程梳理、摩擦点识别、工作流重构与服务可视化改善。",
        skill_title_2: "自动化与生产力",
        skill_text_2: "通过有选择的自动化和 AI 支持，减少重复工作并提升一致性。",
        skill_title_3: "分析与决策支持",
        skill_text_3: "KPI 设计、看板逻辑、汇报结构与面向业务的数据表达。",
        skill_title_4: "兼顾治理的转型",
        skill_text_4: "控制思维、采纳规划、责任结构与务实数字化实施。",
        contact_title: "联系",
        contact_subtitle: "欢迎围绕转型、分析、自动化和运营改善展开交流。",
        contact_text: "如果你希望找到一个既理解业务运营、又把技术当作务实改善杠杆的人，这就是一个合适的对话起点。",
        contact_email_label: "邮箱",
        contact_location_label: "地点",
        contact_location_value: "中国与新加坡",
        label_name: "你的名字",
        label_email: "你的邮箱",
        label_message: "你的留言",
        send_btn: "发送信息",
        success_text: "信息已提交，谢谢。",
        footer_1: "© 2026 LINZHI. 保留所有权利。",
        footer_2: "业务理解、系统思维与技术化执行。"
    }
};

document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;
    const root = document.documentElement;
    const mobileToggle = document.querySelector(".mobile-toggle");
    const sidebar = document.querySelector(".sidebar");
    const navLinks = document.querySelectorAll(".sidebar-menu a");
    const sections = document.querySelectorAll("section[id]");
    const revealItems = document.querySelectorAll(".reveal");
    const langButtons = document.querySelectorAll(".lang-btn");
    const translatableNodes = document.querySelectorAll("[data-i18n]");
    const metaDescription = document.querySelector('meta[name="description"]');
    const tiltCards = document.querySelectorAll(".tilt-card");
    const contactForm = document.getElementById("contactForm");
    const contactFields = document.querySelector(".contact-fields");
    const successMessage = document.getElementById("successMessage");

    const applyLanguage = (lang) => {
        const dictionary = translations[lang] || translations.en;

        translatableNodes.forEach((node) => {
            const key = node.dataset.i18n;
            if (dictionary[key]) {
                node.textContent = dictionary[key];
            }
        });

        document.title = lang === "zh"
            ? "LINZHI | 业务转型作品集"
            : "LINZHI | Business Transformation Portfolio";

        if (metaDescription) {
            metaDescription.setAttribute(
                "content",
                lang === "zh"
                    ? "LINZHI 个人作品集，聚焦业务转型、运营卓越、自动化和数据驱动改善。"
                    : "LINZHI portfolio focused on business transformation, operational excellence, automation, and data-driven improvement."
            );
        }

        root.lang = lang === "zh" ? "zh-CN" : "en";

        langButtons.forEach((button) => {
            button.classList.toggle("is-active", button.dataset.lang === lang);
        });

        localStorage.setItem("portfolio-language", lang);
    };

    const storedLanguage = localStorage.getItem("portfolio-language");
    applyLanguage(translations[storedLanguage] ? storedLanguage : "en");

    const setMenuState = (isOpen) => {
        if (!mobileToggle) {
            return;
        }

        mobileToggle.setAttribute("aria-expanded", String(isOpen));
        body.classList.toggle("menu-open", isOpen);
    };

    if (mobileToggle) {
        mobileToggle.addEventListener("click", () => {
            const isOpen = mobileToggle.getAttribute("aria-expanded") === "true";
            setMenuState(!isOpen);
        });
    }

    navLinks.forEach((link) => {
        link.addEventListener("click", () => {
            if (window.innerWidth <= 920) {
                setMenuState(false);
            }
        });
    });

    document.addEventListener("click", (event) => {
        if (!body.classList.contains("menu-open") || !sidebar || !mobileToggle) {
            return;
        }

        if (!sidebar.contains(event.target) && !mobileToggle.contains(event.target)) {
            setMenuState(false);
        }
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            setMenuState(false);
        }
    });

    langButtons.forEach((button) => {
        button.addEventListener("click", () => applyLanguage(button.dataset.lang));
    });

    const sectionObserver = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) {
                    return;
                }

                const currentId = entry.target.getAttribute("id");
                navLinks.forEach((link) => {
                    link.classList.toggle("active", link.getAttribute("href") === `#${currentId}`);
                });
            });
        },
        {
            rootMargin: "-36% 0px -45% 0px",
            threshold: 0.08
        }
    );

    sections.forEach((section) => sectionObserver.observe(section));

    const revealObserver = new IntersectionObserver(
        (entries, observer) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) {
                    return;
                }

                entry.target.classList.add("is-visible");
                observer.unobserve(entry.target);
            });
        },
        {
            threshold: 0.14,
            rootMargin: "0px 0px -48px 0px"
        }
    );

    revealItems.forEach((item) => revealObserver.observe(item));

    const updateScrollProgress = () => {
        const scrollable = document.documentElement.scrollHeight - window.innerHeight;
        const progress = scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0;
        root.style.setProperty("--scroll-progress", `${Math.min(progress, 100)}%`);
    };

    updateScrollProgress();
    window.addEventListener("scroll", updateScrollProgress, { passive: true });
    window.addEventListener("resize", updateScrollProgress);

    document.addEventListener("pointermove", (event) => {
        const x = `${(event.clientX / window.innerWidth) * 100}%`;
        const y = `${(event.clientY / window.innerHeight) * 100}%`;
        root.style.setProperty("--glow-x", x);
        root.style.setProperty("--glow-y", y);
    });

    tiltCards.forEach((card) => {
        card.addEventListener("pointermove", (event) => {
            const rect = card.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;
            const rotateY = ((x / rect.width) - 0.5) * 8;
            const rotateX = ((y / rect.height) - 0.5) * -8;
            card.style.transform = `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
        });

        card.addEventListener("pointerleave", () => {
            card.style.transform = "";
        });
    });

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            if (contactFields && successMessage) {
                contactFields.classList.add("hidden");
                successMessage.classList.remove("hidden");
            }
        });
    }
});